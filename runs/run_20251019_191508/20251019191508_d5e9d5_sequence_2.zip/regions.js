var recordData = [{"length":4361,"seq_id":"J01749.1","regions":[]}];
var all_regions = {"order":[]};
var resultsData = {};
